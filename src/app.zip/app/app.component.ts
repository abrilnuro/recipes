import { Component, Output } from '@angular/core';
import { RecipeService } from './recipe/recipe.service';
import { Recipe } from './recipe/shared/recipe.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'food-app';

  constructor() {}

  ngOnInit() {
  }
}
