import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit {
  categoryIngredientsList = [
    {
      name: 'Meat',
      icon: '../../assets/img/carrot.png',
      color: '#00BFA5'
    },
    {
      name: 'Fruit',
      icon: '../../assets/img/apple.png',
      color: '#00BFA5'
    },
    {
      name: 'Cereal',
      icon: '../../assets/img/carrot.png',
      color: '#00BFA5'
    },
    {
      name: 'Oil',
      icon: '../../assets/img/carrot.png',
      color: '#00BFA5'
    },
    {
      name: 'Fish',
      icon: '../../assets/img/carrot.png',
      color: '#00BFA5'
    },{
      name: 'Meat',
      icon: '../../assets/img/carrot.png',
      color: '#00BFA5'
    },
    {
      name: 'Fruit',
      icon: '../../assets/img/apple.png',
      color: '#00BFA5'
    },
    {
      name: 'Cereal',
      icon: '../../assets/img/carrot.png',
      color: '#00BFA5'
    },
    {
      name: 'Oil',
      icon: '../../assets/img/carrot.png',
      color: '#00BFA5'
    },
    {
      name: 'Fish',
      icon: '../../assets/img/carrot.png',
      color: '#00BFA5'
    }
  ];



  newArrayOfItems = [
    {
      items: [
       {
         title: 'red',
         subTitle: 'f00',
         description: 'toto lorem ispum soil t'
       },
       {
         title: 'red',
         subTitle: 'f00',
         description: 'toto lorem ispum soil t'
       },
       {
         title: 'red',
         subTitle: 'f00',
         description: 'toto lorem ispum soil t'
       },
       {
        title: 'red',
        subTitle: 'f00',
        description: 'toto lorem ispum soil t'
      },
      {
        title: 'red',
        subTitle: 'f00',
        description: 'toto lorem ispum soil t'
      },
      {
        title: 'red',
        subTitle: 'f00',
        description: 'toto lorem ispum soil t'
      }]
    },
    {
      items: [
        {
         title: 'red',
         subTitle: 'f00',
         description: 'toto lorem ispum soil t'
        },
        {
         title: 'red',
         subTitle: 'f00',
         description: 'toto lorem ispum soil t'
        }]
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
