import { Recipe } from './shared/recipe.model';

export class RecipeService {
    recipeList: Recipe[] = [];

    populateList() {
        const recipe1 = new Recipe('Soup',  '../../../assets/img/apple.png');
        const recipe2 = new Recipe('Cake', '../../../assets/img/number_1.png');
        const recipe3 = new Recipe('Pizza', '../../../assets/img/cancel-button.png');
        this.recipeList.push(recipe1);
        this.recipeList.push(recipe2);
        this.recipeList.push(recipe3);
    }

    getRecipeByIndex(index: number): Recipe {
        return this.recipeList[index];
    }
}