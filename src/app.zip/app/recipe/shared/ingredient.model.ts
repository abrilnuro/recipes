export class Ingredient {
    private name: string;
    private amount: number;
    private icon: string;

    constructor(name: string, amount: number, icon: string) {
        this.name = name;
        this.amount = amount;
        this.icon = icon;
    }

    getName(): string {
        return this.name;
    }

    setName(name: string) {
        this.name = name;
    }

    getAmount(): number {
        return this.amount;
    }

    setAmount(amount: number) {
        this.amount = amount;
    }

    getIcon(): string {
        return this.icon;
    }

    setIcon(icon: string) {
        this.icon = icon;
    }
}