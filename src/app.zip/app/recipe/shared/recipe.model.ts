import { Ingredient } from './ingredient.model';

export class Recipe {
    private name: string;
    private image: string;
    private ingredientList: Ingredient[];

    constructor(name: string, image: string) {
        this.name = name;
        this.image = image;
    }

    setName(name: string) {
        this.name = name;
    }

    getName() {
        return this.name;
    }

    setImage(image: string) {
        this.image = image;
    }

    getImage() {
        return this.image;
    }

    setIngredients(ingredientList: Ingredient[]) {
        this.ingredientList = ingredientList;
    }

    getIngredients(): Ingredient[] {
        return this.ingredientList;
    }
}